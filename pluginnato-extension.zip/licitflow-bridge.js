/**
 * PluginNato — Bridge para LicitFlow (v1.0.6 - Sincronização Instantânea)
 * =======================================================================
 * Injetado automaticamente nas abas do LicitFlow (alainmagn.github.io/licitflow).
 * Conecta o armazenamento da extensão e transmite dados em tempo real.
 */

(function () {
  'use strict';

  console.log('[PluginNato Bridge v1.0.6] Conectado à aplicação LicitFlow.');

  // 1. Sinaliza que o PluginNato está ativo
  function anunciarDisponibilidade() {
    window.postMessage({ tipo: 'PLUGINNATO_DISPONIVEL', versao: '1.0.6' }, '*');
  }

  // 2. Transmite dados armazenados imediatamente
  function transmitirDadosArmazenados() {
    chrome.storage.local.get(['historicoProcessos', 'ultimoProcessoSincronizado'], (res) => {
      if (res.historicoProcessos && Object.keys(res.historicoProcessos).length > 0) {
        window.postMessage({
          tipo: 'PLUGINDATA_HISTORICO_COMPLETO',
          historico: res.historicoProcessos
        }, '*');
      }
      if (res.ultimoProcessoSincronizado) {
        window.postMessage({
          tipo: 'PLUGINDATA_UPDATE',
          processo: res.ultimoProcessoSincronizado
        }, '*');
      }
    });
  }

  anunciarDisponibilidade();
  transmitirDadosArmazenados();

  // Repete anúncio para o SPA
  setTimeout(() => {
    anunciarDisponibilidade();
    transmitirDadosArmazenados();
  }, 400);

  // 3. Ouvinte em tempo real de mudanças no storage (quando o usuário navega no SEI)
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      if (changes.historicoProcessos && changes.historicoProcessos.newValue) {
        window.postMessage({
          tipo: 'PLUGINDATA_HISTORICO_COMPLETO',
          historico: changes.historicoProcessos.newValue
        }, '*');
      }
      if (changes.ultimoProcessoSincronizado && changes.ultimoProcessoSincronizado.newValue) {
        window.postMessage({
          tipo: 'PLUGINDATA_UPDATE',
          processo: changes.ultimoProcessoSincronizado.newValue
        }, '*');
      }
    }
  });

  // 4. Mensagens diretas do Service Worker
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.tipo === 'PLUGINDATA_UPDATE') {
      if (msg.historico) {
        window.postMessage({
          tipo: 'PLUGINDATA_HISTORICO_COMPLETO',
          historico: msg.historico
        }, '*');
      }
      if (msg.ultimo) {
        window.postMessage({
          tipo: 'PLUGINDATA_UPDATE',
          processo: msg.ultimo
        }, '*');
      }
    }
  });

  // 5. Atende solicitação de dados vinda do LicitFlow
  window.addEventListener('message', (event) => {
    if (event.data && event.data.tipo === 'PEDIR_DADOS_PLUGINNATO') {
      anunciarDisponibilidade();
      transmitirDadosArmazenados();
    }
  });
})();
