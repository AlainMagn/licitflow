/**
 * PluginNato — Background Service Worker (v1.0.3 - 100% Seguro & Passivo)
 * =========================================================================
 * - ZERO requisições de rede ao SEI (impede qualquer conflito com o SIP/sessão)
 * - Armazena e mescla com inteligência os dados capturados passivamente pelo content script
 * - Envia atualizações em tempo real para a aplicação LicitFlow
 */

const LICITFLOW_DEFAULT_URL = 'https://alainmagn.github.io/licitflow/';

// Inicialização
chrome.runtime.onInstalled.addListener(() => {
  console.log('[PluginNato v1.0.3] Service Worker iniciado em modo seguro e passivo.');
  chrome.storage.local.get(['config'], (res) => {
    if (!res.config) {
      chrome.storage.local.set({
        config: {
          appUrl: LICITFLOW_DEFAULT_URL,
          autoSync: true,
          intervalSeconds: 30
        },
        historicoProcessos: {}
      });
    }
  });
});

/**
 * Escuta mensagens enviadas passivamente pelo content.js
 */
chrome.runtime.onMessage.addListener((mensagem, sender, sendResponse) => {
  if (mensagem.tipo === 'PROCESSO_DETECTADO_NA_ARVORE') {
    salvarProcesso(mensagem.dados, sender.tab);
    sendResponse({ recebido: true });
  }
  return true;
});

/**
 * Salva e transmite os dados do processo sem fazer nenhum fetch de rede
 */
function salvarProcesso(dadosArvore, tab) {
  const numProcesso = dadosArvore.numeroProcesso || `SEI-${dadosArvore.idProcedimento}`;
  if (!numProcesso) return;

  chrome.storage.local.get(['historicoProcessos', 'config'], (res) => {
    const historico = res.historicoProcessos || {};
    const existente = historico[numProcesso] || {};

    // Mesclagem de agentes (união de nomes únicos)
    const agentesNovos = dadosArvore.agentes || [];
    const agentesExistentes = existente.agentes || [];
    const agentesUnicos = Array.from(new Set([...agentesExistentes, ...agentesNovos]));

    // Preserva artefatos existentes se o frame atual não enviou árvore completa
    let artefatosFinal = dadosArvore.artefatos && dadosArvore.artefatos.length > 0
      ? dadosArvore.artefatos
      : (existente.artefatos || []);

    // Preserva objeto se o atual for genérico e o existente for mais detalhado
    let objetoFinal = dadosArvore.objeto;
    if ((!objetoFinal || objetoFinal === 'Demanda extraída do SEI! Bahia') && existente.objeto) {
      objetoFinal = existente.objeto;
    }

    const pacoteCompleto = {
      numeroProcesso: numProcesso,
      idProcedimento: dadosArvore.idProcedimento || existente.idProcedimento || '',
      objeto: objetoFinal || 'Demanda em instrução no SEI! Bahia',
      totalDocumentos: artefatosFinal.length,
      artefatos: artefatosFinal,
      agentes: agentesUnicos,
      ultimaAtualizacao: new Date().toISOString(),
      tabTitle: tab ? tab.title : (existente.tabTitle || 'SEI! Bahia')
    };

    historico[numProcesso] = pacoteCompleto;

    chrome.storage.local.set({
      historicoProcessos: historico,
      ultimoProcessoSincronizado: pacoteCompleto
    });

    // Transmite para abas do LicitFlow se abertas
    transmitirParaLicitFlow(pacoteCompleto);
  });
}

/**
 * Transmissão instantânea para qualquer aba do LicitFlow aberta
 */
function transmitirParaLicitFlow(pacote) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((t) => {
      if (t.url && (t.url.includes('licitflow') || t.url.includes('alainmagn.github.io') || t.url.includes('localhost'))) {
        chrome.tabs.sendMessage(t.id, {
          tipo: 'PLUGINDATA_UPDATE',
          payload: pacote
        }).catch(() => {});
      }
    });
  });
}
