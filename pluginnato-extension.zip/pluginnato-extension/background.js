/**
 * PluginNato — Background Service Worker (v1.0.4 - Leitura e Mesclagem Semântica)
 * =========================================================================
 * - ZERO requisições de rede ao SEI (impede qualquer conflito com o SIP/sessão)
 * - Armazena e mescla com inteligência os dados capturados passivamente pelo content script
 * - Preserva e prioriza Pregoeiro identificado, Valor Estimado, Data de Sessão e Artefatos
 * - Envia atualizações em tempo real para a aplicação LicitFlow
 */

const LICITFLOW_DEFAULT_URL = 'https://alainmagn.github.io/licitflow/';

// Inicialização
chrome.runtime.onInstalled.addListener(() => {
  console.log('[PluginNato v1.0.4] Service Worker iniciado.');
  chrome.storage.local.get(['config'], (res) => {
    if (!res.config) {
      chrome.storage.local.set({
        config: {
          appUrl: LICITFLOW_DEFAULT_URL,
          autoSync: true,
          intervalSeconds: 30
        },
        historicoProcessos: {}
      });
    }
  });
});

/**
 * Escuta mensagens enviadas passivamente pelo content.js
 */
chrome.runtime.onMessage.addListener((mensagem, sender, sendResponse) => {
  if (mensagem.tipo === 'PROCESSO_DETECTADO_NA_ARVORE') {
    salvarProcesso(mensagem.dados, sender.tab);
    sendResponse({ recebido: true });
  }
  return true;
});

/**
 * Salva e transmite os dados do processo sem fazer nenhum fetch de rede
 */
function salvarProcesso(dadosArvore, tab) {
  const numProcesso = dadosArvore.numeroProcesso || `SEI-${dadosArvore.idProcedimento}`;
  if (!numProcesso) return;

  chrome.storage.local.get(['historicoProcessos', 'config'], (res) => {
    const historico = res.historicoProcessos || {};
    const existente = historico[numProcesso] || {};

    // 1. Mesclagem de agentes (união de nomes únicos)
    const agentesNovos = dadosArvore.agentes || [];
    const agentesExistentes = existente.agentes || [];
    const agentesUnicos = Array.from(new Set([...agentesExistentes, ...agentesNovos]));

    // 2. Pregoeiro / Agente de Contratação designado
    let pregoeiroFinal = dadosArvore.pregoeiro || existente.pregoeiro || '';
    if (!pregoeiroFinal && dadosArvore.usuarioLogado && (dadosArvore.usuarioLogado.toUpperCase().includes('RENATO') || dadosArvore.usuarioLogado.toUpperCase().includes('CARVALHO'))) {
      pregoeiroFinal = 'Renato Carvalho';
    }

    // 3. Equipe de apoio
    const equipeApoioFinal = (dadosArvore.equipeApoio && dadosArvore.equipeApoio.length > 0)
      ? dadosArvore.equipeApoio
      : (existente.equipeApoio || []);

    // 4. Artefatos da árvore
    let artefatosFinal = dadosArvore.artefatos && dadosArvore.artefatos.length > 0
      ? dadosArvore.artefatos
      : (existente.artefatos || []);

    // 5. Objeto da contratação
    let objetoFinal = dadosArvore.objeto;
    if ((!objetoFinal || objetoFinal === 'Demanda extraída do SEI! Bahia') && existente.objeto) {
      objetoFinal = existente.objeto;
    }

    // 6. Valor estimado
    let valorEstimadoFinal = (dadosArvore.valorEstimado && dadosArvore.valorEstimado > 0)
      ? dadosArvore.valorEstimado
      : (existente.valorEstimado || 0);

    // 7. Data de abertura / sessão
    let dataAberturaFinal = dadosArvore.dataAbertura || existente.dataAbertura || '';

    // 8. Edital
    let editalFinal = dadosArvore.edital || existente.edital || '';

    const pacoteCompleto = {
      numeroProcesso: numProcesso,
      idProcedimento: dadosArvore.idProcedimento || existente.idProcedimento || '',
      objeto: objetoFinal || 'Demanda em instrução no SEI! Bahia',
      pregoeiro: pregoeiroFinal,
      agentePrincipal: pregoeiroFinal || existente.agentePrincipal || (agentesUnicos.length > 0 ? agentesUnicos[0] : 'Agente em Identificação'),
      equipeApoio: equipeApoioFinal,
      valorEstimado: valorEstimadoFinal,
      dataAbertura: dataAberturaFinal,
      edital: editalFinal,
      totalDocumentos: artefatosFinal.length,
      artefatos: artefatosFinal,
      agentes: agentesUnicos,
      usuarioLogado: dadosArvore.usuarioLogado || existente.usuarioLogado || '',
      ultimaAtualizacao: new Date().toISOString(),
      tabTitle: tab ? tab.title : (existente.tabTitle || 'SEI! Bahia')
    };

    historico[numProcesso] = pacoteCompleto;

    chrome.storage.local.set({
      historicoProcessos: historico,
      ultimoProcessoSincronizado: pacoteCompleto
    });

    // Transmite para abas do LicitFlow se abertas
    transmitirParaLicitFlow(pacoteCompleto);
  });
}

/**
 * Transmissão instantânea para qualquer aba do LicitFlow aberta
 */
function transmitirParaLicitFlow(pacote) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((t) => {
      if (t.url && (t.url.includes('licitflow') || t.url.includes('alainmagn.github.io') || t.url.includes('localhost'))) {
        chrome.tabs.sendMessage(t.id, {
          tipo: 'PLUGINDATA_UPDATE',
          payload: pacote
        }).catch(() => {});
      }
    });
  });
}
