/**
 * PluginNato — Background Service Worker (v1.0.6 - Foco Absoluto no Essencial)
 * ==============================================================================
 * Gerencia a sincronização em tempo real entre o SEI! Bahia e o LicitFlow:
 * 1. Processos lidos (Bandeja e Árvore)
 * 2. Atribuição na bandeja do SEI
 * 3. Peças já inseridas até o momento
 *
 * 100% Passivo (zero chamadas de rede ao SEI) e Transmissão Contínua Instantânea.
 */

chrome.runtime.onInstalled.addListener(() => {
  console.log('[PluginNato v1.0.6] Service Worker pronto.');
  chrome.storage.local.get(['historicoProcessos'], (res) => {
    if (!res.historicoProcessos) {
      chrome.storage.local.set({ historicoProcessos: {} });
    }
  });
});

chrome.runtime.onMessage.addListener((mensagem, sender, sendResponse) => {
  // 1. Processos detectados na bandeja do SEI
  if (mensagem.tipo === 'BANDEJA_DETECTADA') {
    salvarProcessosBandeja(mensagem.processos);
    sendResponse({ recebido: true });
    return true;
  }

  // 2. Processo aberto detectado com suas peças inseridas
  if (mensagem.tipo === 'PROCESSO_ARVORE_DETECTADO') {
    salvarProcessoArvore(mensagem.dados);
    sendResponse({ recebido: true });
    return true;
  }

  return true;
});

/**
 * Salva processos encontrados na bandeja
 */
function salvarProcessosBandeja(processosBandeja) {
  if (!processosBandeja || processosBandeja.length === 0) return;

  chrome.storage.local.get(['historicoProcessos'], (res) => {
    const historico = res.historicoProcessos || {};
    let houveMudanca = false;

    processosBandeja.forEach(pb => {
      const num = pb.numeroProcesso;
      if (!num) return;

      if (!historico[num]) {
        historico[num] = {
          numeroProcesso: num,
          atribuidoA: pb.atribuidoA || 'Não atribuído',
          pecas: [],
          totalPecas: 0,
          ultimaAtualizacao: new Date().toISOString()
        };
        houveMudanca = true;
      } else {
        // Atualiza a atribuição se mudou
        if (pb.atribuidoA && pb.atribuidoA !== 'Não atribuído' && historico[num].atribuidoA !== pb.atribuidoA) {
          historico[num].atribuidoA = pb.atribuidoA;
          historico[num].ultimaAtualizacao = new Date().toISOString();
          houveMudanca = true;
        }
      }
    });

    if (houveMudanca) {
      chrome.storage.local.set({ historicoProcessos: historico });
      transmitirParaLicitFlow(historico);
    }
  });
}

/**
 * Salva processo com suas peças extraídas da árvore
 */
function salvarProcessoArvore(dados) {
  const num = dados.numeroProcesso;
  if (!num) return;

  chrome.storage.local.get(['historicoProcessos'], (res) => {
    const historico = res.historicoProcessos || {};
    const existente = historico[num] || {};

    const atribuicaoFinal = dados.atribuidoA && dados.atribuidoA !== 'Não atribuído'
      ? dados.atribuidoA
      : (existente.atribuidoA || dados.atribuidoA || 'Renato Carvalho');

    const pecasFinais = (dados.pecas && dados.pecas.length > 0)
      ? dados.pecas
      : (existente.pecas || []);

    const pacote = {
      numeroProcesso: num,
      atribuidoA: atribuicaoFinal,
      pecas: pecasFinais,
      totalPecas: pecasFinais.length,
      ultimaAtualizacao: new Date().toISOString()
    };

    historico[num] = pacote;

    chrome.storage.local.set({
      historicoProcessos: historico,
      ultimoProcessoSincronizado: pacote
    });

    transmitirParaLicitFlow(historico, pacote);
  });
}

/**
 * Envia os dados atualizados para todas as abas abertas do LicitFlow
 */
function transmitirParaLicitFlow(historico, ultimo) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((t) => {
      if (t.url && (t.url.includes('licitflow') || t.url.includes('alainmagn.github.io') || t.url.includes('localhost'))) {
        chrome.tabs.sendMessage(t.id, {
          tipo: 'PLUGINDATA_UPDATE',
          historico: historico,
          ultimo: ultimo
        }).catch(() => {});
      }
    });
  });
}
