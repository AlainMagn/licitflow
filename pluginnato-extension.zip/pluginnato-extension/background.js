/**
 * PluginNato — Background Service Worker (v1.0.5 - Zero Digitação & Ponte Contínua)
 * ===============================================================================
 * - ZERO requisições de rede ao SEI (100% passivo e imune a bloqueios do SIP)
 * - Armazena e transmite dados semânticos completos para o LicitFlow em tempo real
 */

const LICITFLOW_DEFAULT_URL = 'https://alainmagn.github.io/licitflow/';

chrome.runtime.onInstalled.addListener(() => {
  console.log('[PluginNato v1.0.5] Service Worker ativo.');
  chrome.storage.local.get(['config'], (res) => {
    if (!res.config) {
      chrome.storage.local.set({
        config: {
          appUrl: LICITFLOW_DEFAULT_URL,
          autoSync: true
        },
        historicoProcessos: {}
      });
    }
  });
});

chrome.runtime.onMessage.addListener((mensagem, sender, sendResponse) => {
  if (mensagem.tipo === 'PROCESSO_DETECTADO_NA_ARVORE') {
    salvarProcesso(mensagem.dados, sender.tab);
    sendResponse({ recebido: true });
  }
  return true;
});

function salvarProcesso(dados, tab) {
  const numProcesso = dados.numeroProcesso || `SEI-${dados.idProcedimento}`;
  if (!numProcesso) return;

  chrome.storage.local.get(['historicoProcessos', 'config'], (res) => {
    const historico = res.historicoProcessos || {};
    const existente = historico[numProcesso] || {};

    // Preserva artefatos existentes se o frame atual enviou lista menor
    let artefatosFinal = dados.artefatos && dados.artefatos.length > 0
      ? dados.artefatos
      : (existente.artefatos || []);

    // Preserva objeto se o atual for genérico e o existente for detalhado
    let objetoFinal = dados.objeto;
    if ((!objetoFinal || objetoFinal === 'Demanda em instrução no SEI! Bahia') && existente.objeto) {
      objetoFinal = existente.objeto;
    }

    // Pregoeiro: Renato Carvalho
    const pregoeiroFinal = dados.pregoeiro || existente.pregoeiro || 'Renato Carvalho';

    const pacoteCompleto = {
      numeroProcesso: numProcesso,
      idProcedimento: dados.idProcedimento || existente.idProcedimento || '',
      objeto: objetoFinal || 'Demanda em instrução no SEI! Bahia',
      tipoProcesso: dados.tipoProcesso || existente.tipoProcesso || 'Pregão Eletrônico',
      modalidade: dados.tipoProcesso || existente.modalidade || 'Pregão Eletrônico',
      pregoeiro: pregoeiroFinal,
      agentePrincipal: pregoeiroFinal,
      estagio: dados.estagio || existente.estagio || 1,
      pilaresStatus: dados.pilaresStatus || existente.pilaresStatus || {},
      totalDocumentos: artefatosFinal.length,
      artefatos: artefatosFinal,
      assinaturas: Array.from(new Set([...(existente.assinaturas || []), ...(dados.assinaturas || [])])),
      valorEstimado: (dados.valorEstimado && dados.valorEstimado > 0) ? dados.valorEstimado : (existente.valorEstimado || 0),
      ultimaAtualizacao: new Date().toISOString(),
      tabTitle: tab ? tab.title : (existente.tabTitle || 'SEI! Bahia')
    };

    historico[numProcesso] = pacoteCompleto;

    chrome.storage.local.set({
      historicoProcessos: historico,
      ultimoProcessoSincronizado: pacoteCompleto
    });

    transmitirParaLicitFlow(pacoteCompleto);
  });
}

function transmitirParaLicitFlow(pacote) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((t) => {
      if (t.url && (t.url.includes('licitflow') || t.url.includes('alainmagn.github.io') || t.url.includes('localhost'))) {
        chrome.tabs.sendMessage(t.id, {
          tipo: 'PLUGINDATA_UPDATE',
          payload: pacote
        }).catch(() => {});
      }
    });
  });
}
