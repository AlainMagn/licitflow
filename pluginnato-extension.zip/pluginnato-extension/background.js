/**
 * PluginNato — Background Service Worker (v1.0.2 - 100% Seguro & Passivo)
 * =========================================================================
 * - ZERO requisições de rede ao SEI (impede qualquer conflito com o SIP/sessão)
 * - Apenas armazena os dados capturados passivamente pelo content script
 * - Envia atualizações em tempo real para a aplicação LicitFlow
 */

const LICITFLOW_DEFAULT_URL = 'https://alainmagn.github.io/licitflow/';
const ALARM_NAME = 'pluginnato_heartbeat_sync';

// Inicialização
chrome.runtime.onInstalled.addListener(() => {
  console.log('[PluginNato v1.0.2] Service Worker iniciado em modo seguro e passivo.');
  chrome.storage.local.get(['config'], (res) => {
    if (!res.config) {
      chrome.storage.local.set({
        config: {
          appUrl: LICITFLOW_DEFAULT_URL,
          autoSync: true,
          intervalSeconds: 30
        },
        historicoProcessos: {}
      });
    }
  });
});

/**
 * Escuta mensagens enviadas passivamente pelo content.js
 */
chrome.runtime.onMessage.addListener((mensagem, sender, sendResponse) => {
  if (mensagem.tipo === 'PROCESSO_DETECTADO_NA_ARVORE') {
    salvarProcesso(mensagem.dados, sender.tab);
    sendResponse({ recebido: true });
  }
  return true;
});

/**
 * Salva e transmite os dados do processo sem fazer nenhum fetch de rede
 */
function salvarProcesso(dadosArvore, tab) {
  const numProcesso = dadosArvore.numeroProcesso || `SEI-${dadosArvore.idProcedimento}`;
  if (!numProcesso) return;

  const pacoteCompleto = {
    numeroProcesso: numProcesso,
    idProcedimento: dadosArvore.idProcedimento,
    totalDocumentos: dadosArvore.totalDocumentosArvore || (dadosArvore.artefatos ? dadosArvore.artefatos.length : 0),
    artefatos: dadosArvore.artefatos || [],
    agentes: dadosArvore.agentes || [],
    ultimaAtualizacao: new Date().toISOString(),
    tabTitle: tab ? tab.title : 'SEI! Bahia'
  };

  chrome.storage.local.get(['historicoProcessos', 'config'], (res) => {
    const historico = res.historicoProcessos || {};
    historico[numProcesso] = pacoteCompleto;

    chrome.storage.local.set({
      historicoProcessos: historico,
      ultimoProcessoSincronizado: pacoteCompleto
    });

    // Transmite para abas do LicitFlow se abertas
    transmitirParaLicitFlow(pacoteCompleto, res.config ? res.config.appUrl : LICITFLOW_DEFAULT_URL);
  });
}

/**
 * Transmissão instantânea para qualquer aba do LicitFlow aberta
 */
function transmitirParaLicitFlow(pacote, appUrl) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((t) => {
      if (t.url && (t.url.includes('licitflow') || t.url.includes('alainmagn.github.io') || t.url.includes('localhost'))) {
        chrome.tabs.sendMessage(t.id, {
          tipo: 'PLUGINDATA_UPDATE',
          payload: pacote
        }).catch(() => {});
      }
    });
  });
}
