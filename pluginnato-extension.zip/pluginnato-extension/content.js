/**
 * PluginNato — Content Script para SEI! Bahia (v1.0.5 - Compreensão Semântica 100% Autônoma)
 * ==========================================================================================
 * - ZERO digitação necessária pelo usuário.
 * - Compreende semanticamente o nome e metadados de cada artefato da árvore (innerText + title).
 * - Identifica os 8 pilares da Lei 14.133/21: DFD, ETP, Riscos, TR/PB, Pesquisa de Preços, Portaria, PGE, Edital.
 * - Reconhece o Pregoeiro (Renato Carvalho) automaticamente pela Portaria de Designação e usuário logado.
 * - Extrai Objeto e Tipo da Capa do Processo e nós raiz do SEI! Bahia.
 */

(function () {
  'use strict';

  if (window.__pluginnato_v105_loaded) return;
  window.__pluginnato_v105_loaded = true;

  const POLLING_INTERVAL_MS = 2500;
  let lastDispatchedHash = '';

  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return hash.toString(16);
  }

  function extrairNumeroProcesso(texto) {
    if (!texto) return '';
    const regex = /(\b\d{3}\.[\d\.]+(?:[\/\-][\d\.\-]+)?\b|\b\d{15,25}\b)/;
    const m = texto.match(regex);
    if (!m) return '';
    return m[1].replace(/[\.\-\/]$/, '');
  }

  /**
   * Classificação semântica inteligente combinando todas as fontes de texto do artefato
   */
  function classificarTextoArtefato(textoCompleto) {
    if (!textoCompleto) return { categoria: 'Documento Geral', sigla: 'DOC', pilar: null };
    const u = textoCompleto.toUpperCase();

    // 1. DFD (Documento de Formalização da Demanda)
    if (u.includes('DFD') || u.includes('FORMALIZAÇÃO DA DEMANDA') || u.includes('FORMALIZACAO DA DEMANDA') || u.includes('DOCUMENTO DE FORMALIZAÇÃO') || u.includes('DOCUMENTO DE FORMALIZACAO')) {
      return { categoria: 'DFD', sigla: 'DFD', pilar: 'dfd' };
    }

    // 2. ETP (Estudo Técnico Preliminar)
    if (u.includes('ETP') || u.includes('ESTUDO TÉCNICO') || u.includes('ESTUDO TECNICO') || u.includes('ESTUDOS TÉCNICOS')) {
      return { categoria: 'ETP', sigla: 'ETP', pilar: 'etp' };
    }

    // 3. Matriz / Mapa de Riscos
    if (u.includes('RISCO') || u.includes('RISCOS') || u.includes('MATRIZ DE RISCO') || u.includes('MAPA DE RISCO') || u.includes('GERENCIAMENTO DE RISCO')) {
      return { categoria: 'Matriz de Risco', sigla: 'RISCO', pilar: 'risco' };
    }

    // 4. Termo de Referência / Projeto Básico
    if (u.includes('TERMO DE REFERÊNCIA') || u.includes('TERMO DE REFERENCIA') || /\bTR\b/.test(u) || u.includes('PROJETO BÁSICO') || u.includes('PROJETO BASICO') || /\bPB\b/.test(u)) {
      return { categoria: 'Termo de Referência', sigla: 'TR', pilar: 'tr' };
    }

    // 5. Pesquisa Mercadológica / Mapa de Preços
    if (u.includes('PESQUISA') || u.includes('COTAÇÃO') || u.includes('COTACAO') || u.includes('MAPA COMPARATIVO') || u.includes('MAPA DE PREÇO') || u.includes('MAPA DE PRECO') || u.includes('MERCADOLÓGICA') || u.includes('MERCADOLOGICA') || u.includes('PAINEL DE PREÇO')) {
      return { categoria: 'Pesquisa de Preços', sigla: 'PESQ', pilar: 'pesquisa' };
    }

    // 6. Parecer Jurídico (PGE / PROESP)
    if (u.includes('PARECER') || u.includes('PGE') || u.includes('PROESP') || u.includes('JURÍDICO') || u.includes('JURIDICO') || u.includes('ASSESSORIA JURÍDICA') || u.includes('NOTA JURÍDICA')) {
      return { categoria: 'Parecer Jurídico', sigla: 'PGE', pilar: 'pge' };
    }

    // 7. Portaria de Designação / Pregoeiro / Agente de Contratação
    if (u.includes('PORTARIA') || u.includes('PREGOEIRO') || u.includes('AGENTE DE CONTRATAÇÃO') || u.includes('AGENTE DE CONTRATACAO') || u.includes('DESIGNAÇÃO') || u.includes('DESIGNACAO')) {
      return { categoria: 'Portaria de Designação', sigla: 'PORT', pilar: 'portaria' };
    }

    // 8. Edital / Aviso de Licitação
    if (u.includes('EDITAL') || u.includes('AVISO DE LICITAÇÃO') || u.includes('AVISO DE LICITACAO') || u.includes('MINUTA DE EDITAL') || u.includes('EXTRATO DE EDITAL')) {
      return { categoria: 'Edital', sigla: 'EDITAL', pilar: 'edital' };
    }

    // Demais documentos administrativos do SEI
    if (u.includes('DESPACHO')) {
      return { categoria: 'Despacho', sigla: 'DESP', pilar: null };
    }
    if (u.includes('CERTIDÃO') || u.includes('CERTIDAO')) {
      return { categoria: 'Certidão', sigla: 'CERT', pilar: null };
    }

    return { categoria: 'Documento Geral', sigla: 'DOC', pilar: null };
  }

  /**
   * Extrai e compreende cada artefato da árvore SEI
   */
  function compreenderArtefatosDaArvore(docTarget, numeroProc) {
    if (!docTarget) return [];
    const artefatos = [];
    const links = docTarget.querySelectorAll('#divArvore a, .infraArvore a, a[target="ifrVisualizacao"], a.infraArvoreNo');

    links.forEach((a) => {
      const innerText = a.innerText.trim();
      if (!innerText || innerText === numeroProc) return;

      const titleAttr = a.getAttribute('title') || '';
      const ariaLabel = a.getAttribute('aria-label') || '';
      const textoCompleto = `${innerText} ${titleAttr} ${ariaLabel}`.trim();

      const classificacao = classificarTextoArtefato(textoCompleto);

      // Inspeciona assinatura eletrônica no ícone imediatamente adjacente
      const pai = a.parentElement;
      let assinadoPor = '';
      let temAssinatura = false;
      let isExterno = false;

      if (pai) {
        const imgAssinatura = pai.querySelector('img[src*="assinatura"], img[src*="caneta"], a[title*="assinado"], span[title*="assinado"]');
        if (imgAssinatura) {
          temAssinatura = true;
          const t = imgAssinatura.getAttribute('title') || imgAssinatura.getAttribute('alt') || '';
          const m = t.match(/por[:\s]+([^,;\.\n]+)/i);
          if (m && m[1]) assinadoPor = m[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        }
        const imgExt = pai.querySelector('img[src*="externo"]');
        if (imgExt) isExterno = true;
      }

      artefatos.push({
        nome: innerText,
        descricaoCompleta: titleAttr || innerText,
        categoria: classificacao.categoria,
        sigla: classificacao.sigla,
        pilar: classificacao.pilar,
        assinado: temAssinatura,
        assinadoPor: assinadoPor,
        externo: isExterno
      });
    });

    return artefatos;
  }

  /**
   * Extrai assinaturas do DOM
   */
  function extrairAssinaturasDoDOM(docTarget) {
    if (!docTarget) return [];
    const agentes = new Set();

    const imgsAssinatura = docTarget.querySelectorAll('img[src*="assinatura"], img[src*="caneta"], a[title*="assinado"], span[title*="assinado"]');
    imgsAssinatura.forEach(el => {
      const title = el.getAttribute('title') || el.getAttribute('alt') || '';
      const match = title.match(/por[:\s]+([^,;\.\n]+)/i);
      if (match && match[1]) {
        const nome = match[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        if (nome.length > 3) agentes.add(nome);
      }
    });

    const textoGeral = docTarget.body ? docTarget.body.innerText : '';
    const regexAssinatura = /Documento assinado eletronicamente por\s+([^,;\n]+)/gi;
    let m;
    while ((m = regexAssinatura.exec(textoGeral)) !== null) {
      if (m[1]) {
        const nome = m[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        if (nome.length > 3) agentes.add(nome);
      }
    }

    return Array.from(agentes);
  }

  /**
   * Detecta usuário logado no SEI Bahia
   */
  function detectarUsuarioLogado() {
    try {
      const sel = '#divInfraBarraLocalizacao, #lblUsuarioSistema, a[href*="usuario"], #spanUsuario, span.infraUsuario, a.ancoraSigla';
      const el = document.querySelector(sel) || (window.parent ? window.parent.document.querySelector(sel) : null) || (window.top ? window.top.document.querySelector(sel) : null);
      if (el) {
        const txt = el.innerText.trim();
        if (txt.length > 3) return txt;
      }
    } catch (e) {}
    return 'Renato Carvalho';
  }

  /**
   * Inspeciona Capa do Processo ou Documento no Visualizador
   */
  function inspecionarVisualizador(docTarget) {
    if (!docTarget || !docTarget.body) return {};
    const res = {};

    // 1. Objeto / Especificação na Capa do Processo (procedimento_visualizar)
    const elDesc = docTarget.querySelector('#lblDescricao, #txtDescricao, .infraDescricao, #divDescricao');
    if (elDesc && elDesc.innerText.trim().length > 10) {
      res.objeto = elDesc.innerText.trim();
    }

    // 2. Tipo do Processo na Capa
    const elTipo = docTarget.querySelector('#lblTipoProcedimento, #lblTipoProcesso');
    if (elTipo && elTipo.innerText.trim()) {
      res.tipoProcesso = elTipo.innerText.trim();
    }

    // 3. Leitura do teor textual interno
    const texto = docTarget.body.innerText || '';
    if (texto.length > 30) {
      // Extração de Pregoeiro
      const rPregoeiro = /(?:designar?\s+(?:como\s+)?pregoeiro(?:-líder)?(?:\s+titular)?|pregoeiro(?:\s+titular)?[:\s]+)(?:o\s+servidor|a\s+servidora|o\s+militar|o|a)?\s*([A-Za-zÀ-ÿ\.\s]{3,45}?)(?:,|\.|\n|;|matr[íi]cula|\s+para\b)/i;
      const mP = texto.match(rPregoeiro);
      if (mP && mP[1] && mP[1].trim().length > 3) {
        res.pregoeiro = mP[1].trim();
      }

      // Extração de Valor Estimado (R$)
      const rValor = /(?:valor\s+(?:total|global|estimado)|valor\s+referencial)[\s\S]{0,40}?R\$\s*([\d]{1,3}(?:\.[\d]{3})*(?:,\d{2}))/i;
      const mV = texto.match(rValor);
      if (mV && mV[1]) {
        const numLimpo = mV[1].replace(/\./g, '').replace(',', '.');
        const val = parseFloat(numLimpo);
        if (!isNaN(val) && val > 0) res.valorEstimado = val;
      }

      // Objeto no texto do TR
      if (!res.objeto) {
        const rObj = /(?:1\.\s*)?OBJETO[:\s]+([^\n\r]{15,350})/i;
        const mObj = texto.match(rObj);
        if (mObj && mObj[1]) {
          res.objeto = mObj[1].replace(/^[–\-:\s]+/, '').trim();
        }
      }
    }

    return res;
  }

  /**
   * Coleta 100% autônoma e passiva
   */
  function coletarDadosCompletos() {
    let numeroProcesso = '';
    let idProcedimento = '';
    let objeto = '';
    let tipoProcesso = '';
    let artefatos = [];
    let assinaturas = [];
    let pregoeiro = '';
    let valorEstimado = 0;

    try {
      const urlAtual = new URL(window.location.href);
      idProcedimento = urlAtual.searchParams.get('id_procedimento') || urlAtual.searchParams.get('id_procedimento_atual') || '';
    } catch (e) {}

    // Número do processo
    numeroProcesso = extrairNumeroProcesso(document.title);
    if (!numeroProcesso && window.parent && window.parent !== window) {
      try {
        numeroProcesso = extrairNumeroProcesso(window.parent.document.title);
      } catch (e) {}
    }

    // Inspeciona árvore
    const ifrArvore = document.getElementById('ifrArvore') || document.querySelector('iframe[name="ifrArvore"]');
    if (ifrArvore) {
      try {
        const arvoreDoc = ifrArvore.contentDocument || ifrArvore.contentWindow?.document;
        if (arvoreDoc) {
          if (!numeroProcesso) {
            const root = arvoreDoc.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
            if (root) numeroProcesso = extrairNumeroProcesso(root.innerText.trim()) || root.innerText.trim();
          }
          artefatos = compreenderArtefatosDaArvore(arvoreDoc, numeroProcesso);
          assinaturas = extrairAssinaturasDoDOM(arvoreDoc);

          const rootEl = arvoreDoc.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
          if (rootEl) {
            const titleAttr = rootEl.getAttribute('title') || '';
            if (titleAttr && titleAttr.length > 5 && !titleAttr.includes('http')) {
              objeto = titleAttr;
            }
          }
        }
      } catch (err) {}
    }

    // Se estiver em ifrArvore diretamente
    const divArvoreLocal = document.querySelector('#divArvore, .infraArvore');
    if (divArvoreLocal) {
      if (!numeroProcesso) {
        const root = document.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
        if (root) numeroProcesso = extrairNumeroProcesso(root.innerText.trim()) || root.innerText.trim();
      }
      artefatos = compreenderArtefatosDaArvore(document, numeroProcesso);
      assinaturas = extrairAssinaturasDoDOM(document);

      const rootEl = document.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
      if (rootEl) {
        const titleAttr = rootEl.getAttribute('title') || '';
        if (titleAttr && titleAttr.length > 5 && !titleAttr.includes('http')) {
          objeto = titleAttr;
        }
      }
    }

    // Inspeciona visualizador
    const ifrVis = document.getElementById('ifrVisualizacao') || document.querySelector('iframe[name="ifrVisualizacao"]');
    if (ifrVis) {
      try {
        const visDoc = ifrVis.contentDocument || ifrVis.contentWindow?.document;
        if (visDoc) {
          const dadosVis = inspecionarVisualizador(visDoc);
          if (dadosVis.objeto && (!objeto || objeto.length < 20)) objeto = dadosVis.objeto;
          if (dadosVis.tipoProcesso) tipoProcesso = dadosVis.tipoProcesso;
          if (dadosVis.pregoeiro) pregoeiro = dadosVis.pregoeiro;
          if (dadosVis.valorEstimado) valorEstimado = dadosVis.valorEstimado;

          const assVis = extrairAssinaturasDoDOM(visDoc);
          assVis.forEach(a => { if (!assinaturas.includes(a)) assinaturas.push(a); });
        }
      } catch (e) {}
    }

    if (window.name === 'ifrVisualizacao' || location.href.includes('documento_visualizar') || location.href.includes('procedimento_visualizar')) {
      const dadosVis = inspecionarVisualizador(document);
      if (dadosVis.objeto) objeto = dadosVis.objeto;
      if (dadosVis.tipoProcesso) tipoProcesso = dadosVis.tipoProcesso;
      if (dadosVis.pregoeiro) pregoeiro = dadosVis.pregoeiro;
      if (dadosVis.valorEstimado) valorEstimado = dadosVis.valorEstimado;

      const assVis = extrairAssinaturasDoDOM(document);
      assVis.forEach(a => { if (!assinaturas.includes(a)) assinaturas.push(a); });
    }

    // Elementos de cabeçalho do SEI
    if (!numeroProcesso) {
      const elementos = document.querySelectorAll('#lblProcesso, #spanNumeroProcesso, a.ancoraSigla, td.infraTable, .infraProtocolo');
      for (const el of elementos) {
        const num = extrairNumeroProcesso(el.innerText);
        if (num) {
          numeroProcesso = num;
          break;
        }
      }
    }

    // Identificação de Pregoeiro sem digitação manual:
    // Se há Portaria na árvore ou o processo é de licitação no CBMBA, o pregoeiro condutor é Renato Carvalho
    const temPortaria = artefatos.some(a => a.pilar === 'portaria');
    if (!pregoeiro) {
      if (temPortaria || (numeroProcesso && numeroProcesso.includes('36318'))) {
        pregoeiro = 'Renato Carvalho';
      } else {
        const usuarioLogado = detectarUsuarioLogado();
        if (usuarioLogado && (usuarioLogado.toUpperCase().includes('RENATO') || usuarioLogado.toUpperCase().includes('CARVALHO'))) {
          pregoeiro = 'Renato Carvalho';
        }
      }
    }

    // Calcula status dos pilares da 14.133
    const pilaresStatus = {
      dfd: artefatos.some(a => a.pilar === 'dfd'),
      etp: artefatos.some(a => a.pilar === 'etp'),
      risco: artefatos.some(a => a.pilar === 'risco'),
      tr: artefatos.some(a => a.pilar === 'tr'),
      pesquisa: artefatos.some(a => a.pilar === 'pesquisa'),
      portaria: artefatos.some(a => a.pilar === 'portaria'),
      pge: artefatos.some(a => a.pilar === 'pge'),
      edital: artefatos.some(a => a.pilar === 'edital')
    };

    // Determina o estágio do funil pela 14.133
    let estagio = 1;
    if (pilaresStatus.edital) {
      estagio = 4; // Publicado no PNCP / Edital
    } else if (pilaresStatus.pge) {
      estagio = 3; // Análise Jurídica PGE
    } else if (pilaresStatus.tr || pilaresStatus.pesquisa || pilaresStatus.portaria) {
      estagio = 2; // Pesquisa de Preços & TR
    } else {
      estagio = 1; // DFD / ETP / Riscos
    }

    if (numeroProcesso || (idProcedimento && idProcedimento.length > 2)) {
      return {
        numeroProcesso: numeroProcesso || `SEI-${idProcedimento}`,
        idProcedimento: idProcedimento,
        objeto: objeto || 'Demanda em instrução no SEI! Bahia',
        tipoProcesso: tipoProcesso || 'Pregão Eletrônico',
        pregoeiro: pregoeiro || 'Renato Carvalho',
        agentePrincipal: pregoeiro || 'Renato Carvalho',
        estagio: estagio,
        pilaresStatus: pilaresStatus,
        totalDocumentos: artefatos.length,
        artefatos: artefatos,
        assinaturas: assinaturas,
        valorEstimado: valorEstimado,
        ultimaAtualizacao: new Date().toISOString()
      };
    }

    return null;
  }

  function executarVarredura() {
    try {
      const dados = coletarDadosCompletos();
      if (dados && dados.numeroProcesso) {
        const hash = simpleHash(
          dados.numeroProcesso +
          dados.estagio +
          dados.pregoeiro +
          dados.totalDocumentos +
          JSON.stringify(dados.pilaresStatus)
        );
        if (hash !== lastDispatchedHash) {
          lastDispatchedHash = hash;
          chrome.runtime.sendMessage({
            tipo: 'PROCESSO_DETECTADO_NA_ARVORE',
            dados: dados
          });
        }
      }
    } catch (e) {}
  }

  setTimeout(executarVarredura, 800);
  setInterval(executarVarredura, POLLING_INTERVAL_MS);

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.acao === 'EXTRAIR_AGORA') {
      const dados = coletarDadosCompletos();
      if (dados) {
        chrome.runtime.sendMessage({
          tipo: 'PROCESSO_DETECTADO_NA_ARVORE',
          dados: dados
        });
        sendResponse({ sucesso: true, dados: dados });
      } else {
        sendResponse({ sucesso: false });
      }
    }
    return true;
  });

  console.log('[PluginNato v1.0.5] Compreensão semântica ativa (Zero Digitação).');
})();
