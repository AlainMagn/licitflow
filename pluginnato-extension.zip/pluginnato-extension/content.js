/**
 * PluginNato — Content Script para SEI! Bahia (v1.0.2 - 100% Passivo & Seguro)
 * =========================================================================
 * Opera EXCLUSIVAMENTE em modo de leitura (Read-Only) da memória DOM.
 * NUNCA faz chamadas de rede (fetch/XHR) ao servidor do SEI.
 * NUNCA interfere no ciclo de vida da sessão ou no SIP (Sistema de Permissões).
 */

(function () {
  'use strict';

  if (window.__pluginnato_v102_loaded) return;
  window.__pluginnato_v102_loaded = true;

  const POLLING_INTERVAL_MS = 10000;
  let lastDispatchedHash = '';

  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return hash.toString(16);
  }

  function extrairNumeroProcesso(texto) {
    if (!texto) return '';
    const regex = /(\d{3}\.\d{3,6}\.\d{4}[\.\-\/]\d{2,10}|\d{3}\.[\d\.]+\-\d{2}|\d{3}\.[\d\.]+\/\d{4}-\d{2}|\d{12,25})/;
    const m = texto.match(regex);
    return m ? m[1] : '';
  }

  function classificarArtefato(nomeDoc) {
    if (!nomeDoc) return 'Outro';
    const upper = nomeDoc.toUpperCase();

    if (upper.includes('DFD') || upper.includes('FORMALIZAÇÃO DA DEMANDA')) return 'DFD';
    if (upper.includes('ETP') || upper.includes('ESTUDO TÉCNICO PRELIMINAR')) return 'ETP';
    if (upper.includes('MATRIZ DE RISCO') || upper.includes('MAPA DE RISCO') || upper.includes('GERENCIAMENTO DE RISCO')) return 'Matriz de Risco';
    if (upper.includes('TERMO DE REFERÊNCIA') || upper.includes('TR ') || upper.startsWith('TR-')) return 'Termo de Referência';
    if (upper.includes('PROJETO BÁSICO') || upper.includes('PB ')) return 'Projeto Básico';
    if (upper.includes('PESQUISA DE PREÇO') || upper.includes('MAPA COMPARATIVO') || upper.includes('COTAÇÃO') || upper.includes('MAPA DE PREÇOS')) return 'Pesquisa de Preços';
    if (upper.includes('PORTARIA') && (upper.includes('PREGOEIRO') || upper.includes('AGENTE') || upper.includes('DESIGNA') || upper.includes('EQUIPE'))) return 'Portaria de Designação';
    if (upper.includes('PARECER') || upper.includes('PGE') || upper.includes('PROESP') || upper.includes('ASSESSORIA JURÍDICA') || upper.includes('JURÍDICO')) return 'Parecer Jurídico';
    if (upper.includes('EDITAL') || upper.includes('AVISO DE LICITAÇÃO')) return 'Edital';
    if (upper.includes('DESPACHO')) return 'Despacho';
    if (upper.includes('CERTIDÃO')) return 'Certidão';

    return 'Documento Geral';
  }

  /**
   * Extrai agentes a partir de tooltips de assinatura ou corpo de documentos
   */
  function extrairAgentesDoDOM(docTarget) {
    if (!docTarget) return [];
    const agentes = new Set();

    // 1. Procura em imagens de assinatura com tooltip/title no SEI
    const imgsAssinatura = docTarget.querySelectorAll('img[src*="assinatura"], img[src*="caneta"], a[title*="assinado"], span[title*="assinado"]');
    imgsAssinatura.forEach(el => {
      const title = el.getAttribute('title') || el.getAttribute('alt') || '';
      // Ex: "Documento assinado eletronicamente por CAP PM LEONARDO..."
      const match = title.match(/por[:\s]+([^,;\.\n]+)/i);
      if (match && match[1]) {
        const nome = match[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        if (nome.length > 3) agentes.add(nome);
      }
    });

    // 2. Procura em rodapés de assinatura eletrônica (se estiver no visualizador)
    const textoGeral = docTarget.body ? docTarget.body.innerText : '';
    const regexAssinatura = /Documento assinado eletronicamente por\s+([^,;\n]+)/gi;
    let m;
    while ((m = regexAssinatura.exec(textoGeral)) !== null) {
      if (m[1]) {
        const nome = m[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        if (nome.length > 3) agentes.add(nome);
      }
    }

    return Array.from(agentes);
  }

  /**
   * Extrai artefatos da árvore sem alterar ou interferir nos links
   */
  function extrairArtefatos(docTarget, numeroProc) {
    if (!docTarget) return [];
    const artefatos = [];
    const links = docTarget.querySelectorAll('#divArvore a, .infraArvore a, a[target="ifrVisualizacao"], a.infraArvoreNo');

    links.forEach((a) => {
      const nome = a.innerText.trim();
      if (!nome || nome === numeroProc) return;

      const categoria = classificarArtefato(nome);
      const pai = a.parentElement;
      const htmlPai = pai ? pai.innerHTML : '';

      const temAssinatura =
        htmlPai.includes('assinatura') ||
        htmlPai.includes('caneta') ||
        (pai && pai.querySelector('img[src*="assinatura"], img[src*="caneta"]') !== null);

      const isExterno =
        htmlPai.includes('externo') ||
        (pai && pai.querySelector('img[src*="externo"]') !== null);

      artefatos.push({
        nome: nome,
        categoria: categoria,
        assinado: !!temAssinatura,
        externo: !!isExterno
      });
    });

    return artefatos;
  }

  /**
   * Coleta dados passivamente na memória da página
   */
  function coletarDadosPassivos() {
    let numeroProcesso = '';
    let idProcedimento = '';
    let artefatos = [];
    let agentes = [];

    // Tenta obter o ID do procedimento via URL
    try {
      const urlAtual = new URL(window.location.href);
      idProcedimento = urlAtual.searchParams.get('id_procedimento') || urlAtual.searchParams.get('id_procedimento_atual') || '';
    } catch (e) {}

    // Número do processo via título da página
    numeroProcesso = extrairNumeroProcesso(document.title);
    if (!numeroProcesso && window.parent && window.parent !== window) {
      try {
        numeroProcesso = extrairNumeroProcesso(window.parent.document.title);
      } catch (e) {}
    }

    // Se estiver no TOP frame, inspeciona ifrArvore e ifrVisualizacao sem recarregar nada
    const ifrArvore = document.getElementById('ifrArvore') || document.querySelector('iframe[name="ifrArvore"]');
    if (ifrArvore) {
      try {
        const arvoreDoc = ifrArvore.contentDocument || ifrArvore.contentWindow?.document;
        if (arvoreDoc) {
          if (!numeroProcesso) {
            const root = arvoreDoc.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
            if (root) numeroProcesso = extrairNumeroProcesso(root.innerText.trim()) || root.innerText.trim();
          }
          artefatos = extrairArtefatos(arvoreDoc, numeroProcesso);
          agentes = extrairAgentesDoDOM(arvoreDoc);
        }
      } catch (err) {}
    }

    // Se estiver dentro de ifrArvore diretamente
    const divArvoreLocal = document.querySelector('#divArvore, .infraArvore');
    if (divArvoreLocal) {
      if (!numeroProcesso) {
        const root = document.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
        if (root) numeroProcesso = extrairNumeroProcesso(root.innerText.trim()) || root.innerText.trim();
      }
      artefatos = extrairArtefatos(document, numeroProcesso);
      agentes = extrairAgentesDoDOM(document);
    }

    // Se estiver no ifrVisualizacao diretamente
    if (agentes.length === 0) {
      agentes = extrairAgentesDoDOM(document);
    }

    // Elementos clássicos de cabeçalho
    if (!numeroProcesso) {
      const elementos = document.querySelectorAll('#lblProcesso, #spanNumeroProcesso, a.ancoraSigla, td.infraTable, .infraProtocolo');
      for (const el of elementos) {
        const num = extrairNumeroProcesso(el.innerText);
        if (num) {
          numeroProcesso = num;
          break;
        }
      }
    }

    if (numeroProcesso || (idProcedimento && idProcedimento.length > 2)) {
      return {
        numeroProcesso: numeroProcesso || `SEI-${idProcedimento}`,
        idProcedimento: idProcedimento,
        totalDocumentosArvore: artefatos.length,
        artefatos: artefatos,
        agentes: agentes,
        ultimaAtualizacao: new Date().toISOString()
      };
    }

    return null;
  }

  function executarVarredura() {
    try {
      const dados = coletarDadosPassivos();
      if (dados && dados.numeroProcesso) {
        const hash = simpleHash(dados.numeroProcesso + dados.totalDocumentosArvore + (dados.agentes ? dados.agentes.length : 0));
        if (hash !== lastDispatchedHash) {
          lastDispatchedHash = hash;
          chrome.runtime.sendMessage({
            tipo: 'PROCESSO_DETECTADO_NA_ARVORE',
            dados: dados
          });
        }
      }
    } catch (e) {}
  }

  // Execução periódica leve e passiva
  setTimeout(executarVarredura, 1200);
  setInterval(executarVarredura, POLLING_INTERVAL_MS);

  // Escuta requisição explícita do pop-up
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.acao === 'EXTRAIR_AGORA') {
      const dados = coletarDadosPassivos();
      if (dados) {
        chrome.runtime.sendMessage({
          tipo: 'PROCESSO_DETECTADO_NA_ARVORE',
          dados: dados
        });
        sendResponse({ sucesso: true, dados: dados });
      } else {
        sendResponse({ sucesso: false });
      }
    }
    return true;
  });

  console.log('[PluginNato v1.0.2] Monitor passivo e seguro ativo.');
})();
