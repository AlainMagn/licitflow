/**
 * PluginNato — Content Script para SEI! Bahia (v1.0.3 - 100% Passivo & Seguro)
 * =========================================================================
 * Opera EXCLUSIVAMENTE em modo de leitura (Read-Only) da memória DOM.
 * NUNCA faz chamadas de rede (fetch/XHR) ao servidor do SEI.
 * NUNCA interfere no ciclo de vida da sessão ou no SIP (Sistema de Permissões).
 */

(function () {
  'use strict';

  if (window.__pluginnato_v103_loaded) return;
  window.__pluginnato_v103_loaded = true;

  const POLLING_INTERVAL_MS = 3500;
  let lastDispatchedHash = '';

  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return hash.toString(16);
  }

  function extrairNumeroProcesso(texto) {
    if (!texto) return '';
    // Formato clássico Bahia/SEI: 089.1234.2024.0001234-56 ou 030.5678.2025.0000456-12 ou 15 a 25 dígitos
    const regex = /(\b\d{3}\.[\d\.]+(?:[\/\-][\d\.\-]+)?\b|\b\d{15,25}\b)/;
    const m = texto.match(regex);
    if (!m) return '';
    return m[1].replace(/[\.\-\/]$/, '');
  }

  function classificarArtefato(nomeDoc) {
    if (!nomeDoc) return 'Outro';
    const upper = nomeDoc.toUpperCase();

    if (upper.includes('DFD') || upper.includes('FORMALIZAÇÃO DA DEMANDA')) return 'DFD';
    if (upper.includes('ETP') || upper.includes('ESTUDO TÉCNICO PRELIMINAR')) return 'ETP';
    if (upper.includes('MATRIZ DE RISCO') || upper.includes('MAPA DE RISCO') || upper.includes('GERENCIAMENTO DE RISCO')) return 'Matriz de Risco';
    if (upper.includes('TERMO DE REFERÊNCIA') || upper.includes('TR ') || upper.startsWith('TR-')) return 'Termo de Referência';
    if (upper.includes('PROJETO BÁSICO') || upper.includes('PB ')) return 'Projeto Básico';
    if (upper.includes('PESQUISA DE PREÇO') || upper.includes('MAPA COMPARATIVO') || upper.includes('COTAÇÃO') || upper.includes('MAPA DE PREÇOS')) return 'Pesquisa de Preços';
    if (upper.includes('PORTARIA') && (upper.includes('PREGOEIRO') || upper.includes('AGENTE') || upper.includes('DESIGNA') || upper.includes('EQUIPE'))) return 'Portaria de Designação';
    if (upper.includes('PARECER') || upper.includes('PGE') || upper.includes('PROESP') || upper.includes('ASSESSORIA JURÍDICA') || upper.includes('JURÍDICO')) return 'Parecer Jurídico';
    if (upper.includes('EDITAL') || upper.includes('AVISO DE LICITAÇÃO')) return 'Edital';
    if (upper.includes('DESPACHO')) return 'Despacho';
    if (upper.includes('CERTIDÃO')) return 'Certidão';

    return 'Documento Geral';
  }

  /**
   * Extrai agentes a partir de tooltips de assinatura ou corpo de documentos
   */
  function extrairAgentesDoDOM(docTarget) {
    if (!docTarget) return [];
    const agentes = new Set();

    // 1. Procura em imagens de assinatura com tooltip/title no SEI
    const imgsAssinatura = docTarget.querySelectorAll('img[src*="assinatura"], img[src*="caneta"], a[title*="assinado"], span[title*="assinado"]');
    imgsAssinatura.forEach(el => {
      const title = el.getAttribute('title') || el.getAttribute('alt') || '';
      // Ex: "Documento assinado eletronicamente por CAP PM LEONARDO..."
      const match = title.match(/por[:\s]+([^,;\.\n]+)/i);
      if (match && match[1]) {
        const nome = match[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        if (nome.length > 3) agentes.add(nome);
      }
    });

    // 2. Procura em rodapés de assinatura eletrônica (se estiver no visualizador)
    const textoGeral = docTarget.body ? docTarget.body.innerText : '';
    const regexAssinatura = /Documento assinado eletronicamente por\s+([^,;\n]+)/gi;
    let m;
    while ((m = regexAssinatura.exec(textoGeral)) !== null) {
      if (m[1]) {
        const nome = m[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        if (nome.length > 3) agentes.add(nome);
      }
    }

    return Array.from(agentes);
  }

  /**
   * Extrai artefatos da árvore sem alterar ou interferir nos links
   */
  function extrairArtefatos(docTarget, numeroProc) {
    if (!docTarget) return [];
    const artefatos = [];
    const links = docTarget.querySelectorAll('#divArvore a, .infraArvore a, a[target="ifrVisualizacao"], a.infraArvoreNo');

    links.forEach((a) => {
      const nome = a.innerText.trim();
      if (!nome || nome === numeroProc) return;

      const categoria = classificarArtefato(nome);
      const pai = a.parentElement;
      const htmlPai = pai ? pai.innerHTML : '';

      const temAssinatura =
        htmlPai.includes('assinatura') ||
        htmlPai.includes('caneta') ||
        (pai && pai.querySelector('img[src*="assinatura"], img[src*="caneta"]') !== null);

      const isExterno =
        htmlPai.includes('externo') ||
        (pai && pai.querySelector('img[src*="externo"]') !== null);

      artefatos.push({
        nome: nome,
        categoria: categoria,
        assinado: !!temAssinatura,
        externo: !!isExterno
      });
    });

    return artefatos;
  }

  /**
   * Coleta dados passivamente na memória da página
   */
  function coletarDadosPassivos() {
    let numeroProcesso = '';
    let idProcedimento = '';
    let objeto = '';
    let artefatos = [];
    let agentes = [];

    // Tenta obter o ID do procedimento via URL
    try {
      const urlAtual = new URL(window.location.href);
      idProcedimento = urlAtual.searchParams.get('id_procedimento') || urlAtual.searchParams.get('id_procedimento_atual') || '';
    } catch (e) {}

    // 1. Título da página atual
    numeroProcesso = extrairNumeroProcesso(document.title);

    // 2. Título da janela-mãe (top) se estiver em um iframe
    if (!numeroProcesso && window.parent && window.parent !== window) {
      try {
        numeroProcesso = extrairNumeroProcesso(window.parent.document.title);
      } catch (e) {}
    }

    // 3. Se estiver no TOP frame, inspeciona ifrArvore e ifrVisualizacao
    const ifrArvore = document.getElementById('ifrArvore') || document.querySelector('iframe[name="ifrArvore"]');
    if (ifrArvore) {
      try {
        const arvoreDoc = ifrArvore.contentDocument || ifrArvore.contentWindow?.document;
        if (arvoreDoc) {
          if (!numeroProcesso) {
            const root = arvoreDoc.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
            if (root) numeroProcesso = extrairNumeroProcesso(root.innerText.trim()) || root.innerText.trim();
          }
          artefatos = extrairArtefatos(arvoreDoc, numeroProcesso);
          agentes = extrairAgentesDoDOM(arvoreDoc);

          // Objeto via atributo title no nó raiz da árvore
          const rootEl = arvoreDoc.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
          if (rootEl) {
            const titleAttr = rootEl.getAttribute('title') || '';
            if (titleAttr && titleAttr.length > 5 && !titleAttr.includes('http')) {
              objeto = titleAttr;
            }
          }
        }
      } catch (err) {}
    }

    // 4. Se estiver dentro de ifrArvore diretamente
    const divArvoreLocal = document.querySelector('#divArvore, .infraArvore');
    if (divArvoreLocal) {
      if (!numeroProcesso) {
        const root = document.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
        if (root) numeroProcesso = extrairNumeroProcesso(root.innerText.trim()) || root.innerText.trim();
      }
      artefatos = extrairArtefatos(document, numeroProcesso);
      agentes = extrairAgentesDoDOM(document);

      const rootEl = document.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
      if (rootEl) {
        const titleAttr = rootEl.getAttribute('title') || '';
        if (titleAttr && titleAttr.length > 5 && !titleAttr.includes('http')) {
          objeto = titleAttr;
        }
      }
    }

    // 5. Inspeciona o visualizador (seja acessando o iframe ou estando dentro dele)
    const ifrVisLocal = document.getElementById('ifrVisualizacao') || document.querySelector('iframe[name="ifrVisualizacao"]');
    if (ifrVisLocal) {
      try {
        const visDoc = ifrVisLocal.contentDocument || ifrVisLocal.contentWindow?.document;
        if (visDoc) {
          const agentesVis = extrairAgentesDoDOM(visDoc);
          agentesVis.forEach(a => {
            if (!agentes.includes(a)) agentes.push(a);
          });
          if (!objeto) {
            const el = visDoc.querySelector('#lblDescricao, #txtDescricao, .infraDescricao, #divDescricao, td.infraDado');
            if (el && el.innerText.trim().length > 10) {
              objeto = el.innerText.trim();
            }
          }
        }
      } catch (e) {}
    }

    // Se estiver no próprio frame de visualização
    if (window.name === 'ifrVisualizacao' || location.href.includes('documento_visualizar')) {
      const agentesProprios = extrairAgentesDoDOM(document);
      agentesProprios.forEach(a => {
        if (!agentes.includes(a)) agentes.push(a);
      });
    }

    // 6. Elementos clássicos de cabeçalho do SEI
    if (!numeroProcesso) {
      const elementos = document.querySelectorAll('#lblProcesso, #spanNumeroProcesso, a.ancoraSigla, td.infraTable, .infraProtocolo');
      for (const el of elementos) {
        const num = extrairNumeroProcesso(el.innerText);
        if (num) {
          numeroProcesso = num;
          break;
        }
      }
    }

    if (numeroProcesso || (idProcedimento && idProcedimento.length > 2)) {
      return {
        numeroProcesso: numeroProcesso || `SEI-${idProcedimento}`,
        idProcedimento: idProcedimento,
        objeto: objeto || 'Demanda extraída do SEI! Bahia',
        totalDocumentosArvore: artefatos.length,
        artefatos: artefatos,
        agentes: agentes,
        ultimaAtualizacao: new Date().toISOString()
      };
    }

    return null;
  }

  function executarVarredura() {
    try {
      const dados = coletarDadosPassivos();
      if (dados && dados.numeroProcesso) {
        const hash = simpleHash(dados.numeroProcesso + dados.totalDocumentosArvore + (dados.agentes ? dados.agentes.length : 0) + (dados.objeto || ''));
        if (hash !== lastDispatchedHash) {
          lastDispatchedHash = hash;
          chrome.runtime.sendMessage({
            tipo: 'PROCESSO_DETECTADO_NA_ARVORE',
            dados: dados
          });
        }
      }
    } catch (e) {}
  }

  // Execução periódica passiva e leve
  setTimeout(executarVarredura, 1000);
  setInterval(executarVarredura, POLLING_INTERVAL_MS);

  // Escuta requisição explícita do pop-up
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.acao === 'EXTRAIR_AGORA') {
      const dados = coletarDadosPassivos();
      if (dados) {
        chrome.runtime.sendMessage({
          tipo: 'PROCESSO_DETECTADO_NA_ARVORE',
          dados: dados
        });
        sendResponse({ sucesso: true, dados: dados });
      } else {
        sendResponse({ sucesso: false });
      }
    }
    return true;
  });

  console.log('[PluginNato v1.0.3] Monitor passivo e seguro ativo.');
})();
