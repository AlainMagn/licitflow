/**
 * PluginNato — Content Script para SEI! Bahia (v1.0.4 - Leitura Inteligente & Passiva)
 * =========================================================================
 * - Opera EXCLUSIVAMENTE em modo de leitura (Read-Only) da memória DOM.
 * - NUNCA faz chamadas de rede (fetch/XHR) ao servidor do SEI.
 * - Inspeciona o teor interno de documentos abertos no visualizador para detectar:
 *   * Pregoeiro / Agente de Contratação designado (ex: Portarias e Editais)
 *   * Equipe de Apoio
 *   * Valor Estimado (TR / Pesquisa de Preços)
 *   * Objeto real e Data da Sessão
 *   * Usuário logado no SEI
 */

(function () {
  'use strict';

  if (window.__pluginnato_v104_loaded) return;
  window.__pluginnato_v104_loaded = true;

  const POLLING_INTERVAL_MS = 3000;
  let lastDispatchedHash = '';

  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return hash.toString(16);
  }

  function extrairNumeroProcesso(texto) {
    if (!texto) return '';
    const regex = /(\b\d{3}\.[\d\.]+(?:[\/\-][\d\.\-]+)?\b|\b\d{15,25}\b)/;
    const m = texto.match(regex);
    if (!m) return '';
    return m[1].replace(/[\.\-\/]$/, '');
  }

  function classificarArtefato(nomeDoc) {
    if (!nomeDoc) return 'Outro';
    const upper = nomeDoc.toUpperCase();

    if (upper.includes('DFD') || upper.includes('FORMALIZAÇÃO DA DEMANDA')) return 'DFD';
    if (upper.includes('ETP') || upper.includes('ESTUDO TÉCNICO PRELIMINAR')) return 'ETP';
    if (upper.includes('MATRIZ DE RISCO') || upper.includes('MAPA DE RISCO') || upper.includes('GERENCIAMENTO DE RISCO')) return 'Matriz de Risco';
    if (upper.includes('TERMO DE REFERÊNCIA') || upper.includes('TR ') || upper.startsWith('TR-')) return 'Termo de Referência';
    if (upper.includes('PROJETO BÁSICO') || upper.includes('PB ')) return 'Projeto Básico';
    if (upper.includes('PESQUISA DE PREÇO') || upper.includes('MAPA COMPARATIVO') || upper.includes('COTAÇÃO') || upper.includes('MAPA DE PREÇOS') || upper.includes('PESQUISA MERCADOLÓGICA')) return 'Pesquisa de Preços';
    if (upper.includes('PORTARIA') && (upper.includes('PREGOEIRO') || upper.includes('AGENTE') || upper.includes('DESIGNA') || upper.includes('EQUIPE'))) return 'Portaria de Designação';
    if (upper.includes('PARECER') || upper.includes('PGE') || upper.includes('PROESP') || upper.includes('ASSESSORIA JURÍDICA') || upper.includes('JURÍDICO')) return 'Parecer Jurídico';
    if (upper.includes('EDITAL') || upper.includes('AVISO DE LICITAÇÃO')) return 'Edital';
    if (upper.includes('DESPACHO')) return 'Despacho';
    if (upper.includes('CERTIDÃO')) return 'Certidão';

    return 'Documento Geral';
  }

  /**
   * Extrai agentes a partir de tooltips de assinatura ou corpo de documentos
   */
  function extrairAgentesDoDOM(docTarget) {
    if (!docTarget) return [];
    const agentes = new Set();

    // 1. Procura em imagens de assinatura com tooltip/title no SEI
    const imgsAssinatura = docTarget.querySelectorAll('img[src*="assinatura"], img[src*="caneta"], a[title*="assinado"], span[title*="assinado"]');
    imgsAssinatura.forEach(el => {
      const title = el.getAttribute('title') || el.getAttribute('alt') || '';
      const match = title.match(/por[:\s]+([^,;\.\n]+)/i);
      if (match && match[1]) {
        const nome = match[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        if (nome.length > 3) agentes.add(nome);
      }
    });

    // 2. Procura em rodapés de assinatura eletrônica
    const textoGeral = docTarget.body ? docTarget.body.innerText : '';
    const regexAssinatura = /Documento assinado eletronicamente por\s+([^,;\n]+)/gi;
    let m;
    while ((m = regexAssinatura.exec(textoGeral)) !== null) {
      if (m[1]) {
        const nome = m[1].replace(/em\s+\d{2}\/\d{2}.*/i, '').trim();
        if (nome.length > 3) agentes.add(nome);
      }
    }

    return Array.from(agentes);
  }

  /**
   * Extrai artefatos da árvore sem alterar ou interferir nos links
   */
  function extrairArtefatos(docTarget, numeroProc) {
    if (!docTarget) return [];
    const artefatos = [];
    const links = docTarget.querySelectorAll('#divArvore a, .infraArvore a, a[target="ifrVisualizacao"], a.infraArvoreNo');

    links.forEach((a) => {
      const nome = a.innerText.trim();
      if (!nome || nome === numeroProc) return;

      const categoria = classificarArtefato(nome);
      const pai = a.parentElement;
      const htmlPai = pai ? pai.innerHTML : '';

      const temAssinatura =
        htmlPai.includes('assinatura') ||
        htmlPai.includes('caneta') ||
        (pai && pai.querySelector('img[src*="assinatura"], img[src*="caneta"]') !== null);

      const isExterno =
        htmlPai.includes('externo') ||
        (pai && pai.querySelector('img[src*="externo"]') !== null);

      artefatos.push({
        nome: nome,
        categoria: categoria,
        assinado: !!temAssinatura,
        externo: !!isExterno
      });
    });

    return artefatos;
  }

  /**
   * Inspeciona o teor textual interno de um documento no visualizador
   */
  function inspecionarTeorDoDocumento(docTarget) {
    if (!docTarget || !docTarget.body) return {};
    const texto = docTarget.body.innerText || '';
    if (texto.length < 20) return {};

    const resultado = {};

    // 1. Extração de Pregoeiro / Agente de Contratação designado
    // Ex: "Designar como PREGOEIRO o Ten Cel BM RENATO CARVALHO..." ou "Pregoeiro: Maj BM ..."
    const rPregoeiro1 = /designar?\s+(?:como\s+)?pregoeiro(?:-líder)?(?:\s+titular)?\s*(?:o\s+servidor|a\s+servidora|o\s+militar|o|a)?\s*([A-Za-zÀ-ÿ\.\s]{3,45}?)(?:,|\.|\n|;|matr[íi]cula|\s+para\b)/i;
    const mP1 = texto.match(rPregoeiro1);
    if (mP1 && mP1[1] && mP1[1].trim().length > 3) {
      resultado.pregoeiro = mP1[1].trim();
    } else {
      const rPregoeiro2 = /(?:pregoeiro(?:\s+titular)?|agente\s+de\s+contrata[çc][ãa]o)[:\s]+(?:o\s+servidor|a\s+servidora|o\s+militar)?\s*([A-Za-zÀ-ÿ\.\s]{3,45}?)(?:,|\.|\n|;|matr[íi]cula|\s+para\b)/i;
      const mP2 = texto.match(rPregoeiro2);
      if (mP2 && mP2[1] && mP2[1].trim().length > 3) {
        resultado.pregoeiro = mP2[1].trim();
      }
    }

    // 2. Extração de Equipe de Apoio
    const rEquipe = /equipe\s+de\s+apoio[:\s]+([\s\S]*?)(?:Art\.|\n\s*\n|Esta\s+Portaria|§)/i;
    const mEq = texto.match(rEquipe);
    if (mEq && mEq[1]) {
      const linhas = mEq[1].split(/[\n;]/)
        .map(l => l.replace(/^\d+[\.\-\)]\s*/, '').replace(/^[-•*]\s*/, '').trim())
        .filter(l => l.length > 3 && !l.toLowerCase().includes('servidor') && !l.toLowerCase().includes('artigo'));
      if (linhas.length > 0) resultado.equipeApoio = linhas;
    }

    // 3. Extração de Valor Estimado / Total (TR / Pesquisa de Preços)
    const rValor = /(?:valor\s+(?:total|global|estimado)(?:\s+da\s+contrata[çc][ãa]o)?|valor\s+referencial)[\s\S]{0,40}?R\$\s*([\d]{1,3}(?:\.[\d]{3})*(?:,\d{2}))/i;
    const mV = texto.match(rValor);
    if (mV && mV[1]) {
      const numLimpo = mV[1].replace(/\./g, '').replace(',', '.');
      const val = parseFloat(numLimpo);
      if (!isNaN(val) && val > 0) resultado.valorEstimado = val;
    }

    // 4. Extração de Objeto detalhado
    const rObjeto = /(?:1\.\s*)?OBJETO[:\s]+([^\n\r]{15,350})/i;
    const mObj = texto.match(rObjeto);
    if (mObj && mObj[1]) {
      resultado.objeto = mObj[1].replace(/^[–\-:\s]+/, '').trim();
    }

    // 5. Extração de Data da Sessão / Abertura (Edital / Aviso)
    const rSessao = /(?:abertura|sess[ãa]o\s+p[úu]blica|disputa)[\s\S]{0,30}?(\d{2}\/\d{2}\/\d{4})(?:[\s\S]{0,15}?(\d{2}[:h]\d{2}))?/i;
    const mSess = texto.match(rSessao);
    if (mSess && mSess[1]) {
      const d = mSess[1].split('/');
      const hora = mSess[2] ? mSess[2].replace('h', ':') : '09:00';
      resultado.dataAbertura = `${d[2]}-${d[1]}-${d[0]}T${hora}`;
    }

    // 6. Edital / Modalidade
    const rEdital = /((?:PREGÃO\s+ELETRÔNICO|CONCORRÊNCIA|DISPENSA)\s+(?:Nº|N°)?\s*[\d\.\-\/]+)/i;
    const mEd = texto.match(rEdital);
    if (mEd && mEd[1]) {
      resultado.edital = mEd[1].trim();
    }

    return resultado;
  }

  /**
   * Tenta detectar o usuário logado no SEI (top banner)
   */
  function detectarUsuarioLogado() {
    try {
      const sel = '#divInfraBarraLocalizacao, #lblUsuarioSistema, a[href*="usuario"], #spanUsuario, span.infraUsuario, a.ancoraSigla';
      const el = document.querySelector(sel) || (window.parent ? window.parent.document.querySelector(sel) : null);
      if (el) {
        const txt = el.innerText.trim();
        if (txt.length > 3) return txt;
      }
    } catch (e) {}
    return '';
  }

  /**
   * Coleta dados passivamente na memória da página
   */
  function coletarDadosPassivos() {
    let numeroProcesso = '';
    let idProcedimento = '';
    let objeto = '';
    let artefatos = [];
    let agentes = [];
    let pregoeiro = '';
    let equipeApoio = [];
    let valorEstimado = 0;
    let dataAbertura = '';
    let edital = '';

    // Tenta obter o ID do procedimento via URL
    try {
      const urlAtual = new URL(window.location.href);
      idProcedimento = urlAtual.searchParams.get('id_procedimento') || urlAtual.searchParams.get('id_procedimento_atual') || '';
    } catch (e) {}

    // 1. Título da página atual
    numeroProcesso = extrairNumeroProcesso(document.title);

    // 2. Título da janela-mãe (top) se estiver em um iframe
    if (!numeroProcesso && window.parent && window.parent !== window) {
      try {
        numeroProcesso = extrairNumeroProcesso(window.parent.document.title);
      } catch (e) {}
    }

    // 3. Se estiver no TOP frame, inspeciona ifrArvore e ifrVisualizacao
    const ifrArvore = document.getElementById('ifrArvore') || document.querySelector('iframe[name="ifrArvore"]');
    if (ifrArvore) {
      try {
        const arvoreDoc = ifrArvore.contentDocument || ifrArvore.contentWindow?.document;
        if (arvoreDoc) {
          if (!numeroProcesso) {
            const root = arvoreDoc.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
            if (root) numeroProcesso = extrairNumeroProcesso(root.innerText.trim()) || root.innerText.trim();
          }
          artefatos = extrairArtefatos(arvoreDoc, numeroProcesso);
          agentes = extrairAgentesDoDOM(arvoreDoc);

          // Objeto via atributo title no nó raiz da árvore
          const rootEl = arvoreDoc.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
          if (rootEl) {
            const titleAttr = rootEl.getAttribute('title') || '';
            if (titleAttr && titleAttr.length > 5 && !titleAttr.includes('http')) {
              objeto = titleAttr;
            }
          }

          // Inspeciona se na árvore tem menção direta a Pregoeiro na Portaria
          const linksTree = arvoreDoc.querySelectorAll('#divArvore a');
          linksTree.forEach(l => {
            const txt = l.innerText;
            if (txt.toLowerCase().includes('pregoeiro') || txt.toLowerCase().includes('designa')) {
              const rP = /(?:pregoeiro|designa(?:ção)?)\s+([A-Za-zÀ-ÿ\.\s]{3,35})/i;
              const m = txt.match(rP);
              if (m && m[1] && !m[1].toLowerCase().includes('equipe')) {
                pregoeiro = m[1].trim();
              }
            }
          });
        }
      } catch (err) {}
    }

    // 4. Se estiver dentro de ifrArvore diretamente
    const divArvoreLocal = document.querySelector('#divArvore, .infraArvore');
    if (divArvoreLocal) {
      if (!numeroProcesso) {
        const root = document.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
        if (root) numeroProcesso = extrairNumeroProcesso(root.innerText.trim()) || root.innerText.trim();
      }
      artefatos = extrairArtefatos(document, numeroProcesso);
      agentes = extrairAgentesDoDOM(document);

      const rootEl = document.querySelector('#divArvore a, .infraArvoreNoSelecionado, a.infraArvore');
      if (rootEl) {
        const titleAttr = rootEl.getAttribute('title') || '';
        if (titleAttr && titleAttr.length > 5 && !titleAttr.includes('http')) {
          objeto = titleAttr;
        }
      }
    }

    // 5. Inspeciona o visualizador (seja acessando o iframe ou estando dentro dele)
    const ifrVisLocal = document.getElementById('ifrVisualizacao') || document.querySelector('iframe[name="ifrVisualizacao"]');
    if (ifrVisLocal) {
      try {
        const visDoc = ifrVisLocal.contentDocument || ifrVisLocal.contentWindow?.document;
        if (visDoc) {
          const dadosDoc = inspecionarTeorDoDocumento(visDoc);
          if (dadosDoc.pregoeiro) pregoeiro = dadosDoc.pregoeiro;
          if (dadosDoc.equipeApoio) equipeApoio = dadosDoc.equipeApoio;
          if (dadosDoc.valorEstimado) valorEstimado = dadosDoc.valorEstimado;
          if (dadosDoc.objeto && (!objeto || objeto.length < 20)) objeto = dadosDoc.objeto;
          if (dadosDoc.dataAbertura) dataAbertura = dadosDoc.dataAbertura;
          if (dadosDoc.edital) edital = dadosDoc.edital;

          const agentesVis = extrairAgentesDoDOM(visDoc);
          agentesVis.forEach(a => {
            if (!agentes.includes(a)) agentes.push(a);
          });
        }
      } catch (e) {}
    }

    // Se estiver rodando dentro do próprio iframe de visualização
    if (window.name === 'ifrVisualizacao' || location.href.includes('documento_visualizar')) {
      const dadosDoc = inspecionarTeorDoDocumento(document);
      if (dadosDoc.pregoeiro) pregoeiro = dadosDoc.pregoeiro;
      if (dadosDoc.equipeApoio) equipeApoio = dadosDoc.equipeApoio;
      if (dadosDoc.valorEstimado) valorEstimado = dadosDoc.valorEstimado;
      if (dadosDoc.objeto) objeto = dadosDoc.objeto;
      if (dadosDoc.dataAbertura) dataAbertura = dadosDoc.dataAbertura;
      if (dadosDoc.edital) edital = dadosDoc.edital;

      const agentesProprios = extrairAgentesDoDOM(document);
      agentesProprios.forEach(a => {
        if (!agentes.includes(a)) agentes.push(a);
      });
    }

    // 6. Elementos clássicos de cabeçalho do SEI
    if (!numeroProcesso) {
      const elementos = document.querySelectorAll('#lblProcesso, #spanNumeroProcesso, a.ancoraSigla, td.infraTable, .infraProtocolo');
      for (const el of elementos) {
        const num = extrairNumeroProcesso(el.innerText);
        if (num) {
          numeroProcesso = num;
          break;
        }
      }
    }

    const usuarioLogado = detectarUsuarioLogado();

    // Se o usuário logado no SEI for Renato Carvalho e houver Portaria ou processo de licitação,
    // e ainda não tiver pregoeiro definido, sugere o usuário logado
    if (!pregoeiro && usuarioLogado && (usuarioLogado.toUpperCase().includes('RENATO') || usuarioLogado.toUpperCase().includes('CARVALHO'))) {
      const temPortaria = artefatos.some(a => a.categoria === 'Portaria de Designação');
      if (temPortaria) {
        pregoeiro = 'Renato Carvalho';
      }
    }

    if (numeroProcesso || (idProcedimento && idProcedimento.length > 2)) {
      return {
        numeroProcesso: numeroProcesso || `SEI-${idProcedimento}`,
        idProcedimento: idProcedimento,
        objeto: objeto || 'Demanda extraída do SEI! Bahia',
        pregoeiro: pregoeiro,
        equipeApoio: equipeApoio,
        valorEstimado: valorEstimado,
        dataAbertura: dataAbertura,
        edital: edital,
        totalDocumentosArvore: artefatos.length,
        artefatos: artefatos,
        agentes: agentes,
        usuarioLogado: usuarioLogado,
        ultimaAtualizacao: new Date().toISOString()
      };
    }

    return null;
  }

  function executarVarredura() {
    try {
      const dados = coletarDadosPassivos();
      if (dados && dados.numeroProcesso) {
        const hash = simpleHash(
          dados.numeroProcesso +
          (dados.pregoeiro || '') +
          (dados.valorEstimado || 0) +
          dados.totalDocumentosArvore +
          (dados.agentes ? dados.agentes.length : 0) +
          (dados.objeto || '')
        );
        if (hash !== lastDispatchedHash) {
          lastDispatchedHash = hash;
          chrome.runtime.sendMessage({
            tipo: 'PROCESSO_DETECTADO_NA_ARVORE',
            dados: dados
          });
        }
      }
    } catch (e) {}
  }

  // Execução periódica passiva e leve
  setTimeout(executarVarredura, 1000);
  setInterval(executarVarredura, POLLING_INTERVAL_MS);

  // Escuta requisição explícita do pop-up
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.acao === 'EXTRAIR_AGORA') {
      const dados = coletarDadosPassivos();
      if (dados) {
        chrome.runtime.sendMessage({
          tipo: 'PROCESSO_DETECTADO_NA_ARVORE',
          dados: dados
        });
        sendResponse({ sucesso: true, dados: dados });
      } else {
        sendResponse({ sucesso: false });
      }
    }
    return true;
  });

  console.log('[PluginNato v1.0.4] Monitor passivo e leitor de teor interno ativo.');
})();
