/**
 * PluginNato — Bridge para LicitFlow (v1.0.3)
 * =========================================================================
 * Injetado automaticamente nas abas do LicitFlow (alainmagn.github.io/licitflow).
 * Estabelece a ponte bidirecional entre o armazenamento da extensão e o painel web.
 */

(function () {
  'use strict';

  console.log('[PluginNato Bridge v1.0.3] Conectado à aplicação LicitFlow.');

  // 1. Sinaliza ao LicitFlow que a extensão PluginNato está presente e ativa
  function anunciarDisponibilidade() {
    window.postMessage({ tipo: 'PLUGINNATO_DISPONIVEL', versao: '1.0.5' }, '*');
  }

  // 2. Transmite imediatamente os dados mais recentes salvos no SEI
  function transmitirDadosArmazenados() {
    chrome.storage.local.get(['ultimoProcessoSincronizado', 'historicoProcessos'], (res) => {
      if (res.ultimoProcessoSincronizado) {
        window.postMessage({
          tipo: 'PLUGINDATA_UPDATE',
          payload: res.ultimoProcessoSincronizado
        }, '*');
      }
      if (res.historicoProcessos && Object.keys(res.historicoProcessos).length > 0) {
        window.postMessage({
          tipo: 'PLUGINDATA_HISTORICO_COMPLETO',
          payload: res.historicoProcessos
        }, '*');
      }
    });
  }

  anunciarDisponibilidade();
  transmitirDadosArmazenados();

  // Repete anúncio após pequeno delay para garantir que o SPA já registrou os ouvintes
  setTimeout(() => {
    anunciarDisponibilidade();
    transmitirDadosArmazenados();
  }, 500);

  // 3. Ouvinte reativo em tempo real: quando você navega no SEI em outra aba,
  // o storage muda e este ouvinte dispara o evento para a aba do LicitFlow na mesma hora!
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      if (changes.ultimoProcessoSincronizado && changes.ultimoProcessoSincronizado.newValue) {
        window.postMessage({
          tipo: 'PLUGINDATA_UPDATE',
          payload: changes.ultimoProcessoSincronizado.newValue
        }, '*');
      }
      if (changes.historicoProcessos && changes.historicoProcessos.newValue) {
        window.postMessage({
          tipo: 'PLUGINDATA_HISTORICO_COMPLETO',
          payload: changes.historicoProcessos.newValue
        }, '*');
      }
    }
  });

  // 4. Também escuta mensagens diretas enviadas pelo Service Worker
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.tipo === 'PLUGINDATA_UPDATE' && msg.payload) {
      window.postMessage({
        tipo: 'PLUGINDATA_UPDATE',
        payload: msg.payload
      }, '*');
    }
  });

  // 5. Atende requisição de sincronização disparada por botões do LicitFlow
  window.addEventListener('message', (event) => {
    if (event.data && event.data.tipo === 'PEDIR_DADOS_PLUGINNATO') {
      anunciarDisponibilidade();
      transmitirDadosArmazenados();
    }
  });
})();
