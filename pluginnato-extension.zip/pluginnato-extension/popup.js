/**
 * PluginNato — Popup Script (v1.0.6 - Essencial e Direto)
 */

document.addEventListener('DOMContentLoaded', () => {
  const lblProcesso = document.getElementById('lblProcesso');
  const lblTimestamp = document.getElementById('lblTimestamp');
  const lblAtribuidoA = document.getElementById('lblAtribuidoA');
  const badgeTotalPecas = document.getElementById('badgeTotalPecas');
  const listaPecasPreview = document.getElementById('listaPecasPreview');
  const btnAbrirLicitFlow = document.getElementById('btnAbrirLicitFlow');

  function carregarDados() {
    chrome.storage.local.get(['ultimoProcessoSincronizado', 'historicoProcessos'], (res) => {
      let proc = res.ultimoProcessoSincronizado;

      // Se não tiver último sincronizado, pega o primeiro do histórico
      if (!proc && res.historicoProcessos) {
        const chaves = Object.keys(res.historicoProcessos);
        if (chaves.length > 0) {
          proc = res.historicoProcessos[chaves[chaves.length - 1]];
        }
      }

      if (proc && proc.numeroProcesso) {
        lblProcesso.innerText = proc.numeroProcesso;
        lblTimestamp.innerText = `Atualizado: ${new Date(proc.ultimaAtualizacao || Date.now()).toLocaleTimeString('pt-BR')}`;
        lblAtribuidoA.innerText = proc.atribuidoA || 'Renato Carvalho';
        
        const pecas = proc.pecas || [];
        badgeTotalPecas.innerText = `${pecas.length} Peça${pecas.length === 1 ? '' : 's'}`;

        if (pecas.length > 0) {
          listaPecasPreview.innerHTML = '';
          // Mostra até as 5 peças mais recentes
          pecas.slice(-5).forEach(peca => {
            const div = document.createElement('div');
            div.className = 'peca-item-mini';
            div.innerHTML = `
              <span class="peca-tipo">${peca.tipo || 'Doc'}</span>
              <span class="peca-nome" title="${peca.nome}">${peca.nome}</span>
              ${peca.assinado ? '<span class="peca-assinado" title="Assinado eletronicamente">✍</span>' : ''}
            `;
            listaPecasPreview.appendChild(div);
          });
        } else {
          listaPecasPreview.innerHTML = '<span class="empty-text">Aguardando abertura de peças na árvore</span>';
        }
      } else {
        lblProcesso.innerText = 'Nenhum processo capturado';
        lblTimestamp.innerText = 'Navegue no SEI! Bahia';
        lblAtribuidoA.innerText = 'Aguardando bandeja do SEI';
        badgeTotalPecas.innerText = '0 Peças';
        listaPecasPreview.innerHTML = '<span class="empty-text">Abra um processo no SEI para ver as peças</span>';
      }
    });
  }

  carregarDados();

  // Atualização em tempo real caso chegue dados enquanto o popup está aberto
  chrome.storage.onChanged.addListener(() => {
    carregarDados();
  });

  btnAbrirLicitFlow.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://alainmagn.github.io/licitflow/' });
  });
});
