/**
 * PluginNato — Lógica do Pop-up (v1.0.1)
 * =========================================================================
 * - Injeta dinamicamente o content.js se a aba foi aberta antes da instalação
 * - Recupera dados do storage e sincroniza com a aba ativa do SEI em tempo real
 * - Renderiza o checklist da Lei 14.133 e nomes dos agentes
 */

document.addEventListener('DOMContentLoaded', async () => {
  const lblProcesso = document.getElementById('lblProcesso');
  const lblTimestamp = document.getElementById('lblTimestamp');
  const badgeDocs = document.getElementById('badgeDocs');
  const listaAgentes = document.getElementById('listaAgentes');
  const btnAbrirLicitFlow = document.getElementById('btnAbrirLicitFlow');
  const btnCopiarJson = document.getElementById('btnCopiarJson');
  const btnForcarSync = document.getElementById('btnForcarSync');

  const checklistMap = {
    DFD: document.getElementById('itemDFD'),
    ETP: document.getElementById('itemETP'),
    TR: document.getElementById('itemTR'),
    Pesquisa: document.getElementById('itemPesquisa'),
    PGE: document.getElementById('itemPGE'),
    Portaria: document.getElementById('itemPortaria')
  };

  let ultimoPacote = null;
  let appUrl = 'https://alainmagn.github.io/licitflow/';

  /**
   * Renderiza os dados no pop-up
   */
  function renderizarDados(pacote) {
    if (!pacote) return;
    ultimoPacote = pacote;

    lblProcesso.innerText = pacote.numeroProcesso || 'Processo Detectado';
    badgeDocs.innerText = `${pacote.totalDocumentos || (pacote.artefatos ? pacote.artefatos.length : 0)} Docs`;

    if (pacote.ultimaAtualizacao) {
      const d = new Date(pacote.ultimaAtualizacao);
      lblTimestamp.innerText = `Sincronizado às ${d.toLocaleTimeString('pt-BR')}`;
    }

    // Reset Checklist
    Object.values(checklistMap).forEach((el) => {
      el.className = 'check-item missing';
      el.querySelector('.icon').innerText = '○';
    });

    // Marca artefatos presentes
    if (pacote.artefatos && Array.isArray(pacote.artefatos)) {
      pacote.artefatos.forEach((art) => {
        const cat = art.categoria;
        if (cat === 'DFD') marcarItem('DFD');
        if (cat === 'ETP') marcarItem('ETP');
        if (cat === 'Termo de Referência' || cat === 'Projeto Básico') marcarItem('TR');
        if (cat === 'Pesquisa de Preços') marcarItem('Pesquisa');
        if (cat === 'Parecer Jurídico') marcarItem('PGE');
        if (cat === 'Portaria de Designação') marcarItem('Portaria');
      });
    }

    // Renderiza lista de Agentes
    listaAgentes.innerHTML = '';
    if (pacote.agentes && pacote.agentes.length > 0) {
      pacote.agentes.forEach((ag) => {
        const chip = document.createElement('span');
        chip.className = 'agent-chip';
        chip.innerText = ag;
        listaAgentes.appendChild(chip);
      });
    } else {
      listaAgentes.innerHTML = '<span class="empty-text">Aguardando leitura de assinaturas...</span>';
    }
  }

  function marcarItem(key) {
    const el = checklistMap[key];
    if (el) {
      el.className = 'check-item found';
      el.querySelector('.icon').innerText = '✓';
    }
  }

  /**
   * Tenta forçar a extração da aba ativa
   */
  async function sincronizarAbaAtiva() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab || !tab.url) {
        lblTimestamp.innerText = 'Nenhuma aba ativa encontrada.';
        return;
      }

      // Verifica se está no domínio do Governo da Bahia / SEI
      const isSei = tab.url.includes('ba.gov.br') || tab.url.includes('seibahia');
      if (!isSei) {
        lblProcesso.innerText = 'Aba do SEI não detectada';
        lblTimestamp.innerText = 'Navegue até o SEI! Bahia e entre no processo.';
        return;
      }

      // Garante que o content script está injetado (caso a aba tenha sido aberta antes da extensão)
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          files: ['content.js']
        });
      } catch (err) {
        // Ignora se já estiver injetado
      }

      // Solicita a extração imediata
      chrome.tabs.sendMessage(tab.id, { acao: 'EXTRAIR_AGORA' }, (resp) => {
        if (chrome.runtime.lastError) {
          console.log('[PluginNato] Aviso sendMessage:', chrome.runtime.lastError.message);
        }

        if (resp && resp.dados) {
          renderizarDados(resp.dados);
          chrome.storage.local.set({ ultimoProcessoSincronizado: resp.dados });
        } else {
          // Se não respondeu pelo message, lê o storage
          chrome.storage.local.get(['ultimoProcessoSincronizado'], (res) => {
            if (res.ultimoProcessoSincronizado) {
              renderizarDados(res.ultimoProcessoSincronizado);
            }
          });
        }
      });
    } catch (e) {
      console.warn('[PluginNato] Erro ao sincronizar:', e);
    }
  }

  // Carrega do storage local inicialmente
  chrome.storage.local.get(['ultimoProcessoSincronizado', 'config'], (res) => {
    if (res.config && res.config.appUrl) {
      appUrl = res.config.appUrl;
    }
    if (res.ultimoProcessoSincronizado) {
      renderizarDados(res.ultimoProcessoSincronizado);
    }
    // E tenta sincronizar com a aba ativa
    sincronizarAbaAtiva();
  });

  // Botão Atualizar
  btnForcarSync.addEventListener('click', async () => {
    btnForcarSync.innerText = 'Lendo...';
    await sincronizarAbaAtiva();
    setTimeout(() => {
      btnForcarSync.innerText = '↻ Atualizar';
    }, 1000);
  });

  // Botão Copiar JSON
  btnCopiarJson.addEventListener('click', () => {
    chrome.storage.local.get(['ultimoProcessoSincronizado'], (res) => {
      const pacote = ultimoPacote || res.ultimoProcessoSincronizado;
      if (!pacote || !pacote.numeroProcesso) {
        alert('Nenhum processo foi capturado ainda. Abra a página de um processo no SEI! Bahia e clique em Atualizar.');
        return;
      }

      navigator.clipboard.writeText(JSON.stringify(pacote, null, 2)).then(() => {
        const originalText = btnCopiarJson.innerText;
        btnCopiarJson.innerText = '✓ Copiado!';
        setTimeout(() => {
          btnCopiarJson.innerText = originalText;
        }, 1500);
      });
    });
  });

  // Botão Abrir no LicitFlow
  btnAbrirLicitFlow.addEventListener('click', () => {
    chrome.storage.local.get(['ultimoProcessoSincronizado'], (res) => {
      const pacote = ultimoPacote || res.ultimoProcessoSincronizado;
      if (!pacote || !pacote.numeroProcesso) {
        alert('Abra um processo no SEI! Bahia primeiro.');
        return;
      }

      const payloadEncoded = encodeURIComponent(JSON.stringify(pacote));
      const target = `${appUrl}#/import?payload=${payloadEncoded}`;
      chrome.tabs.create({ url: target });
    });
  });
});
